USE Filmes_manha;
GO

SELECT * FROM Generos;
SELECT * FROM Filmes;

SELECT IdGenero, Nome from Generos;